return {
   focus  = require("awful.indicator.focus"),
   resize = require("awful.indicator.resize")
}
